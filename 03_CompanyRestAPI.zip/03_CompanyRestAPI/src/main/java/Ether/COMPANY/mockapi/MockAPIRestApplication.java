package Ether.COMPANY.mockapi;

import javax.ws.rs.ApplicationPath;
import javax.ws.rs.core.Application;

/**
 * Authgenerator Rest Application Extension Class
 */
@ApplicationPath("/")
public class MockAPIRestApplication extends Application {
}
