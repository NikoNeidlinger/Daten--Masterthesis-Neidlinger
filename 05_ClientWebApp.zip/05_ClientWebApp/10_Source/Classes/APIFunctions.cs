﻿namespace INTRANAV_Client_Application.Classes
{
    public class APIFunctions
    {
        const string home = @"http://sales.intranav.io/api/";

    }
}
